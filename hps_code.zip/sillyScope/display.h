#ifndef _DISPLAY_H
#define _DISPLAY_H

#include <cairo.h>

void display_init(void);

void display_redraw(cairo_t *cr);
void display_redraw_banner(cairo_t *cr);

void display_request_redraw(void);
int  display_redraw_pending(void);

#endif //_DISPLAY_H
