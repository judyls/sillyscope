#include "panel.h"
#include <assert.h>

void panel_register(panel_t *panel, panel_t *parent) {
    assert(panel);

    panel->priv.children_head = NULL;
    panel->priv.peer_next = NULL;
    panel->priv.parent = parent;
    if (parent) {
        if (parent->priv.children_head == NULL) {
            parent->priv.children_head = panel;
        } else {
            panel_t *tmp = parent->priv.children_head;
            while (tmp->priv.peer_next) {
                tmp = tmp->priv.peer_next;
            }
            tmp->priv.peer_next = panel;
        }
    }
}

void panel_draw(cairo_t *cr, panel_t *panel) {
    assert(panel);
    // Set the cairo bounds for this panel
    cairo_save(cr);

    // Translate and restrict all draws to the panel bounds
    cairo_translate(cr, panel->x, panel->y);
    cairo_new_path(cr);
    cairo_rectangle(cr, 0, 0, panel->width, panel->height);
    cairo_clip_preserve(cr);

    if (panel->draw) {
        // Draw the background
        cairo_set_source_rgba(cr, panel->bg_color->r,
                                  panel->bg_color->g,
                                  panel->bg_color->b,
                                  panel->bg_color->a);
        cairo_fill_preserve(cr);
        // Draw the edges
        cairo_set_source_rgba(cr, panel->edge_color->r,
                                  panel->edge_color->g,
                                  panel->edge_color->b,
                                  panel->edge_color->a);
        cairo_stroke(cr);

        // Call the panel-specific draw function
        if (panel->callback) {
            cairo_save(cr);
            panel->callback(cr, panel->args);
            cairo_restore(cr);
        }
    } else {
        cairo_new_path(cr);
    }

    panel_t *child = panel->priv.children_head;
    while (child) {
        panel_draw(cr, child);
        child = child->priv.peer_next;
    }

    // Restore the cairo state
    cairo_restore(cr);
}
