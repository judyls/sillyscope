#include "shell.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "scope.h"
#include "display.h"

static void shell_num_chan(void) {
    const char *num_str = strtok(NULL, " \t\n");
    if (!num_str) {
        printf("Error: No number provided\n");
        return;
    }
    const int num = atoi(num_str);

    if (num < 1 || num > NUM_CHAN) {
        printf("Invalid number of channels %d\n", num);
        return;
    }
    printf("Setting number of channels to %d\n", num);

    scope_set_num_channels(num-1);
}

static void shell_timescale(void) {
    const char *time_str = strtok(NULL, " \t\n");
    if (!time_str) {
        printf("Error: No timescale provided\n");
        return;
    }
    const int time = atoi(time_str);

    if (time < 0) {
        printf("Invalid timescale %d\n", time);
        return;
    }
    printf("Setting timescale to %d\n", time);

    scope_set_timescale(time);
}

static void shell_vscale(void) {
    const char *chan_str = strtok(NULL, " \t\n");
    if (!chan_str) {
        printf("Error: No channel provided\n");
        return;
    }
    const char *scale_str = strtok(NULL, " \t\n");
    if (!scale_str) {
        printf("Error: No vscale provided\n");
        return;
    }
    const int chan = atoi(chan_str);
    const int scale = atoi(scale_str);

    if (chan < 0 || chan >= NUM_CHAN) {
        printf("Invalid channel %d\n", chan);
        return;
    }
    if (scale < 0) {
        printf("Invalid vscale %d\n", scale);
        return;
    }
    printf("Setting CH%d vscale to %d\n", chan, scale);

    scope_set_vscale(chan, scale);
}

static void shell_offset(void) {
    const char *chan_str = strtok(NULL, " \t\n");
    if (!chan_str) {
        printf("Error: No channel provided\n");
        return;
    }
    const char *offset_str = strtok(NULL, " \t\n");
    if (!offset_str) {
        printf("Error: No offset provided\n");
        return;
    }
    const int chan = atoi(chan_str);
    const int offset = atoi(offset_str);

    if (chan < 0 || chan >= NUM_CHAN) {
        printf("Invalid channel %d\n", chan);
        return;
    }
    printf("Setting CH%d offset to %d\n", chan, offset);

    scope_set_offset(chan, offset);
}

static void shell_trig_off(void) {
    printf("Turning off triggering\n");
    scope_set_trig_en(0);
}

static void shell_trig_on(void) {
    printf("Turning on triggering\n");
    scope_set_trig_en(1);
}

static void shell_trig_mode(void) {
    const char *mode_str = strtok(NULL, " \t\n");
    if (!mode_str) {
        printf("Error: No mode provided\n");
        return;
    }
    if (strcmp(mode_str, "rising") == 0) {
        printf("Setting trigger mode to rising edge\n");
        scope_set_trig_mode(TRIG_RISING);
    } else if (strcmp(mode_str, "falling") == 0) {
        printf("Setting trigger mode to falling edge\n");
        scope_set_trig_mode(TRIG_FALLING);
    } else if (strcmp(mode_str, "pulse_eq") == 0) {
        printf("Setting trigger mode to pulse equal\n");
        scope_set_trig_mode(TRIG_PULSE_EQ);
    } else if (strcmp(mode_str, "pulse_lt") == 0) {
        printf("Setting trigger mode to pulse less\n");
        scope_set_trig_mode(TRIG_PULSE_LT);
    } else if (strcmp(mode_str, "pulse_gt") == 0) {
        printf("Setting trigger mode to pulse greater\n");
        scope_set_trig_mode(TRIG_PULSE_GT);
    } else {
        printf("Unknown triggering mode %s\n", mode_str);
    }
}

static void shell_trig_chan(void) {
    const char *chan_str = strtok(NULL, " \t\n");
    if (!chan_str) {
        printf("Error: No channel provided\n");
        return;
    }
    const int chan = atoi(chan_str);

    if (chan < 0 || chan >= NUM_CHAN) {
        printf("Invalid channel %d\n", chan);
        return;
    }
    printf("Setting trigger channel to %d\n", chan);

    scope_set_trig_source(chan);
}

static void shell_trig_level(void) {
    const char *level_str = strtok(NULL, " \t\n");
    if (!level_str) {
        printf("Error: No level provided\n");
        return;
    }
    const double level = atof(level_str);

    if (level < 0.0 || level > 1.0) {
        printf("Invalid level %f\n", level);
        return;
    }
    printf("Setting trigger level to %f\n", level);

    scope_set_trig_level(level);
}

static void shell_trig_width(void) {
    const char *width_str = strtok(NULL, " \t\n");
    if (!width_str) {
        printf("Error: No width provided\n");
        return;
    }
    const int width = atoi(width_str);

    if (width < 1) {
        printf("Invalid width %d\n", width);
        return;
    }
    printf("Setting trigger pulse width to %d\n", width);

    scope_set_trig_width(width);
}

static void shell_math_off(void) {
    printf("Turning off math\n");
    scope_set_math_en(0);
}

static void shell_math_on(void) {
    printf("Turning on math\n");
    scope_set_math_en(1);
}

static void shell_math_mode(void) {
    const char *mode_str = strtok(NULL, " \t\n");
    if (!mode_str) {
        printf("Error: No mode provided\n");
        return;
    }
    if (strcmp(mode_str, "add") == 0) {
        printf("Setting math mode to Add\n");
        scope_set_math_mode(MATH_ADD);
    } else if (strcmp(mode_str, "sub") == 0) {
        printf("Setting math mode to Sub\n");
        scope_set_math_mode(TRIG_FALLING);
    } else {
        printf("Unknown math mode %s\n", mode_str);
    }
}

static void shell_math_scale(void) {
    const char *scale_str = strtok(NULL, " \t\n");
    if (!scale_str) {
        printf("Error: No scale provided\n");
        return;
    }
    const int scale = atoi(scale_str);

    if (scale < 0) {
        printf("Invalid scale %d\n", scale);
        return;
    }
    printf("Setting math vscale to %d\n", scale);

    scope_set_math_scale(scale);
}

static void shell_math_offset(void) {
    const char *offset_str = strtok(NULL, " \t\n");
    if (!offset_str) {
        printf("Error: No offset provided\n");
        return;
    }
    const int offset = atoi(offset_str);

    printf("Setting math offset to %d\n", offset);

    scope_set_math_offset(offset);
}

static void shell_math_ch0(void) {
    const char *chan_str = strtok(NULL, " \t\n");
    if (!chan_str) {
        printf("Error: No channel provided\n");
        return;
    }
    const int chan = atoi(chan_str);

    if (chan < 0 || chan >= NUM_CHAN) {
        printf("Invalid channel %d\n", chan);
        return;
    }
    printf("Setting math channel 0 to %d\n", chan);

    scope_set_math_ch0(chan);
}

static void shell_math_ch1(void) {
    const char *chan_str = strtok(NULL, " \t\n");
    if (!chan_str) {
        printf("Error: No channel provided\n");
        return;
    }
    const int chan = atoi(chan_str);

    if (chan < 0 || chan >= NUM_CHAN) {
        printf("Invalid channel %d\n", chan);
        return;
    }
    printf("Setting math channel 1 to %d\n", chan);

    scope_set_math_ch1(chan);
}

static void print_help(void);

typedef struct {
    const char *name;
    const char *desc;
    void (* const func)(void);
} command_t;

static const command_t commands[] = {
    {
        .name = "help",
        .desc = "Print this message",
        .func = print_help
    },
    {
        .name = "num_chan",
        .desc = "Sets the number of active channels",
        .func = shell_num_chan
    },
    {
        .name = "timescale",
        .desc = "Sets the horizontal timescale",
        .func = shell_timescale
    },
    {
        .name = "vscale",
        .desc = "Sets the vertical scale for a channel",
        .func = shell_vscale
    },
    {
        .name = "offset",
        .desc = "Sets the vertical offset for a channel",
        .func = shell_offset
    },
    {
        .name = "trig_off",
        .desc = "Disables triggering",
        .func = shell_trig_off
    },
    {
        .name = "trig_on",
        .desc = "Enables triggering",
        .func = shell_trig_on
    },
    {
        .name = "trig_mode",
        .desc = "Sets the triggering mode",
        .func = shell_trig_mode
    },
    {
        .name = "trig_chan",
        .desc = "Sets the triggering channel",
        .func = shell_trig_chan
    },
    {
        .name = "trig_level",
        .desc = "Sets the triggering level",
        .func = shell_trig_level
    },
    {
        .name = "trig_width",
        .desc = "Sets the triggering pulse width",
        .func = shell_trig_width
    },
    {
        .name = "math_scale",
        .desc = "Sets the vertical scale for math",
        .func = shell_math_scale
    },
    {
        .name = "math_offset",
        .desc = "Sets the vertical offset for math",
        .func = shell_math_offset
    },
    {
        .name = "math_off",
        .desc = "Disables math",
        .func = shell_math_off
    },
    {
        .name = "math_on",
        .desc = "Enables math",
        .func = shell_math_on
    },
    {
        .name = "math_mode",
        .desc = "Sets the math mode",
        .func = shell_math_mode
    },
    {
        .name = "math_ch0",
        .desc = "Enables math channel 0",
        .func = shell_math_ch0
    },
    {
        .name = "math_ch1",
        .desc = "Enables math channel 1",
        .func = shell_math_ch1
    }
};

const int num_commands = sizeof(commands) / sizeof(command_t);

static void print_help() {
    printf("List of commands:\n");
    for (int i = 0; i < num_commands; i++) {
        printf("  %s: %s\n", commands[i].name, commands[i].desc);
    }
}


void shell_run(void) {
    char line[100];
    printf("sillyscope> ");
    while (fgets(line, sizeof(line), stdin)) {
        if (strlen(line) != 0) {
            const char *cmd_str = strtok(line, " \t\n");

            if (strcmp(cmd_str, "exit") == 0) break;

            const command_t *cmd = NULL;
            for (int i = 0; i < num_commands; i++) {
                if (strcmp(commands[i].name, cmd_str) == 0) {
                    cmd = &commands[i];
                    break;
                }
            }

            if (cmd) {
                cmd->func();
                display_request_redraw();
            } else {
                printf("Unknown command \"%s\"\n", cmd_str);
            }
        }

        printf("sillyscope> ");
    }
}
