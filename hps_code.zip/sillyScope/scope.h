#ifndef _SCOPE_H
#define _SCOPE_H

typedef enum {CHAN_1 = 0, CHAN_2, CHAN_3, CHAN_4} chan_t;
#define NUM_CHAN 4

typedef enum {TRIG_RISING = 0, TRIG_FALLING, TRIG_PULSE_EQ, TRIG_PULSE_LT, TRIG_PULSE_GT} trig_mode_t;

typedef enum {MATH_ADD = 0, MATH_SUB} math_mode_t;

void scope_init(void);

void scope_set_num_channels(int num_channels);
int scope_get_num_channels(void);

void scope_set_timescale(int timescale);
double scope_get_timescale(void);

void scope_set_vscale(chan_t chan, int vscale);
double scope_get_vscale(chan_t chan);

void scope_set_offset(chan_t chan, int offset);
double scope_get_offset(chan_t chan);

void scope_set_trig_en(int trig_en);
int scope_get_trig_en(void);

void scope_set_trig_mode(trig_mode_t mode);
trig_mode_t scope_get_trig_mode(void);

void scope_set_trig_level(double trig_level);
double scope_get_trig_level(void);

void scope_set_trig_source(chan_t trig_source);
chan_t scope_get_trig_source(void);

void scope_set_trig_width(int trig_width);
int scope_get_trig_width(void);

void scope_set_math_en(int math_en);
int scope_get_math_en(void);

void scope_set_math_mode(math_mode_t mode);
math_mode_t scope_get_math_mode(void);

void scope_set_math_offset(int offset);
double scope_get_math_offset(void);

void scope_set_math_scale(int scale);
double scope_get_math_scale(void);

void scope_set_math_ch0(chan_t chan);
chan_t scope_get_math_ch0(void);

void scope_set_math_ch1(chan_t chan);
chan_t scope_get_math_ch1(void);

#endif //_SCOPE_H
