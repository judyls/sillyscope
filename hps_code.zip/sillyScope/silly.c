#include <stdlib.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <pthread.h>

#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>

#include "scope.h"
#include "display.h"
#include "surface_hps.h"
#include "shell.h"

static volatile int shutdown_requested = 0;

static pthread_t shell_thread;

void *shell_thread_proc(void *arg) {
    shell_run();

    shutdown_requested = 1;
}

int main (void)
{
    scope_init();
    surface_init();
    display_init();
    display_request_redraw();

    int rc = pthread_create(&shell_thread, NULL, shell_thread_proc, NULL);
    if (rc) {
        printf("ERROR: Failed to create shell thread: %d\n", rc);
        return 1;
    }

    while (!shutdown_requested) {
        if (display_redraw_pending()) {
            display_redraw(surface_get_context());
            surface_write_screen();
        } else {
            display_redraw_banner(surface_get_context());
            surface_write_banner();
        }
        usleep(10000); // sleep for a few milliseconds
    }

    pthread_join(shell_thread, NULL);

    return 0;
}
