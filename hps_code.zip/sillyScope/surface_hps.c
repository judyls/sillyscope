#include "surface_hps.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <string.h>

static unsigned char *virtual_sdram_base;
static int mem_fd;
static cairo_surface_t *s_surf;
static cairo_t *s_cr;

#define HW_SDRAM_BASE ( 0xC8000000 )
#define HW_REGS_SPAN  ( 0x04000000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )

// Allocate the cairo image surface and context, and mmap the overlay SDRAM
void surface_init(void) {
    s_surf = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 640, 480);
    if (cairo_surface_status(s_surf) != CAIRO_STATUS_SUCCESS) {
        printf( "ERROR: Failed to allocate cairo surface\n" );
        exit( 1 );
    }

    s_cr = cairo_create(s_surf);
    if (cairo_status(s_cr) != CAIRO_STATUS_SUCCESS) {
        printf( "ERROR: Failed to allocate cairo context\n" );
        cairo_surface_destroy(s_surf);
        exit( 1 );
    }

    if( ( mem_fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: SDRAM could not open \"/dev/mem\"...\n" );
        exit( 1 );
    }

    virtual_sdram_base = (unsigned char *) mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, mem_fd, HW_SDRAM_BASE );
    if( virtual_sdram_base == MAP_FAILED ) {
        printf( "ERROR: SDRAM mmap() failed...\n" );
        close( mem_fd );
        exit( 1 );
    }
}

cairo_t *surface_get_context(void) {
    return s_cr;
}

// Write the entire cairo buffer to the screen
void surface_write_screen(void) {
    // Need to flush the surface to ensure all data has been written out
    cairo_surface_flush(s_surf);
    unsigned char *cairo_buf = cairo_image_surface_get_data(s_surf);

    memcpy(virtual_sdram_base, cairo_buf, 640*480*4);
}

// Only write the top 32 columns of the cairo buffer to the screen, which
// is enough to cover the colorful banner
void surface_write_banner(void) {
    // Need to flush the surface to ensure all data has been written out
    cairo_surface_flush(s_surf);
    unsigned char *cairo_buf = cairo_image_surface_get_data(s_surf);

    memcpy(virtual_sdram_base, cairo_buf, 640*32*4);
}
