#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <signal.h>

#define HW_REGS_BASE ( 0xff200000 )
#define HW_REGS_SPAN ( 0x00200000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define CFG_PIO_BASE 0x3040

int main(int argc, char* argv[])
{
    volatile unsigned int *h2p_lw_cfg_addr=NULL;
    void *virtual_base;
    int fd;

    if (argc != 3) {
      printf( "Usage: setcfg reg value\n");
      return (1);
    }

    int reg = atoi(argv[1]);
    int value = atoi(argv[2]);
    
    // Open /dev/mem
    if( ( fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: could not open \"/dev/mem\"...\n" );
        return( 1 );
    }
    
    // get virtual addr that maps to physical
    virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, fd, HW_REGS_BASE );    
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: mmap() failed...\n" );
        close( fd );
        return(1);
    }

    // Get the address that maps to the cfg PIO
    h2p_lw_cfg_addr=(unsigned int *)(virtual_base + (( CFG_PIO_BASE ) & ( HW_REGS_MASK ) ));

    printf("cfg %d <= 0x%06x\n", reg, value);

    uint32_t write_value = ((reg & 0xFF) << 24) | (value & 0xFFFFFF);

    *h2p_lw_cfg_addr = write_value;
    *h2p_lw_cfg_addr = 0;

    close( fd );
    return 0;
}
