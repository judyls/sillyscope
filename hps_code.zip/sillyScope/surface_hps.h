#ifndef _SURFACE_HPS_H
#define _SURFACE_HPS_H

#include <cairo.h>

void surface_init(void);
cairo_t *surface_get_context(void);
void surface_write_screen(void);
void surface_write_banner(void);

#endif //_SURFACE_HPS_H
