#include "scope.h"
#include <assert.h>
#include <pthread.h>
#include <inttypes.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>

#define SAMPLE_RATE     (471700)
#define VREF            (4.096)
#define POINTS_PER_GRID (32)

#define HW_REGS_BASE ( 0xff200000 )
#define HW_REGS_SPAN ( 0x00200000 )
#define HW_REGS_MASK ( HW_REGS_SPAN - 1 )
#define CFG_PIO_BASE 0x3040

typedef struct {
    int num_channels;
    int timescale;
    int vscale[NUM_CHAN];
    int offset[NUM_CHAN];
    int trig_en;
    trig_mode_t trig_mode;
    double trig_level;
    chan_t trig_source;
    int trig_width;
    int math_scale;
    int math_offset;
    math_mode_t math_mode;
    int math_en;
    chan_t math_ch0;
    chan_t math_ch1;
} scope_state_t;

static volatile scope_state_t state;

static pthread_mutex_t state_mutex = PTHREAD_MUTEX_INITIALIZER;

static int cfg_fd;

static uint32_t *virtual_cfg_base;

#define CFG_TIMESCALE        (1)
#define CFG_MATH_EN          (3)
#define CFG_NUMCHAN          (4)
#define CFG_TRIG_MODE        (5)
#define CFG_TRIG_EN          (6)
#define CFG_TRIG_LEVEL       (7)
#define CFG_TRIG_PULSE_WIDTH (8)
#define CFG_TRIG_CHAN        (9)
#define CFG_VSCALE           (10)
#define CFG_OFFSET           (11)
#define CFG_COLOR            (12)
#define CFG_MATH_MODE        (20)
#define CFG_MATH_CH0         (21)
#define CFG_MATH_CH1         (22)

static void setcfg(uint32_t reg, uint32_t value) {
    uint32_t write_value = ((reg & 0xFF) << 24) | (value & 0xFFFFFF);
    *virtual_cfg_base = write_value;
    *virtual_cfg_base = 0;
}

void scope_init(void) {

    // Open /dev/mem
    if( ( cfg_fd = open( "/dev/mem", ( O_RDWR | O_SYNC ) ) ) == -1 ) {
        printf( "ERROR: CFG could not open \"/dev/mem\"...\n" );
        exit( 1 );
    }
    
    // get virtual addr that maps the configuration register space to physical
    void *virtual_base = mmap( NULL, HW_REGS_SPAN, ( PROT_READ | PROT_WRITE ), MAP_SHARED, cfg_fd, HW_REGS_BASE );    
    if( virtual_base == MAP_FAILED ) {
        printf( "ERROR: CFG mmap() failed...\n" );
        close( cfg_fd );
        exit(1);
    }

    virtual_cfg_base = (uint32_t*) (virtual_base + (( CFG_PIO_BASE ) & ( HW_REGS_MASK ) ));

    // Set all the scope configuration to a known state
    scope_set_num_channels(0);
    scope_set_timescale(0);
    for (int i = 0; i < NUM_CHAN; i++) {
        scope_set_vscale(i, 4);
        scope_set_offset(i, 0);
    }
    scope_set_trig_en(1);
    scope_set_trig_mode(TRIG_RISING);
    scope_set_trig_level(0.5);
    scope_set_trig_source(CHAN_1);

    scope_set_math_en(0);
    scope_set_math_mode(MATH_ADD);
    scope_set_math_ch0(0);
    scope_set_math_ch1(1);
    scope_set_math_offset(0);
    scope_set_math_scale(4);
}

void scope_set_num_channels(int num_channels) {
    assert(num_channels < NUM_CHAN);

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_NUMCHAN, num_channels);
    state.num_channels = num_channels;
    pthread_mutex_unlock(&state_mutex);
}
int scope_get_num_channels(void) {
    return state.num_channels;
}

void scope_set_timescale(int timescale) {
    assert(timescale >= 0);

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_TIMESCALE, timescale);
    state.timescale = timescale;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_timescale(void) {
    double sample_interval = 1.0 / SAMPLE_RATE;
    // Sample rate gets adjusted by number of channels
    sample_interval *= (state.num_channels+1); 
    sample_interval *= (state.timescale+1);

    return sample_interval * POINTS_PER_GRID;
}

void scope_set_vscale(chan_t chan, int vscale) {
    assert(vscale > 0);
    assert(chan < NUM_CHAN);

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_VSCALE + 2*chan, vscale);
    state.vscale[chan] = vscale;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_vscale(chan_t chan) {
    assert(chan < NUM_CHAN);
    double volts_per_pix = 0.001 * 8; // account for mult by 8 in display module
    // vscale value multiplies with the pixel address
    volts_per_pix /= state.vscale[chan];
    volts_per_pix *= 4; // Allow for the scale down factor

    return volts_per_pix * POINTS_PER_GRID;
}

void scope_set_offset(chan_t chan, int offset) {
    assert(chan < NUM_CHAN);

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_OFFSET + 2*chan, offset);
    state.offset[chan] = offset;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_offset(chan_t chan) {
    assert(chan < NUM_CHAN);
    return state.offset[chan];
}

void scope_set_trig_en(int trig_en) {
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_TRIG_EN, trig_en);
    state.trig_en = trig_en;
    pthread_mutex_unlock(&state_mutex);
}
int scope_get_trig_en(void) {
    return state.trig_en;
}

void scope_set_trig_mode(trig_mode_t mode) {
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_TRIG_MODE, mode);
    state.trig_mode = mode;
    pthread_mutex_unlock(&state_mutex);
}
trig_mode_t scope_get_trig_mode(void) {
    return state.trig_mode;
}

void scope_set_trig_level(double trig_level) {
    pthread_mutex_lock(&state_mutex);
    uint32_t cfg_level = (uint32_t) (trig_level * 4095);
    setcfg(CFG_TRIG_LEVEL, cfg_level);
    state.trig_level = trig_level;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_trig_level(void) {
    return state.trig_level;
}

void scope_set_trig_source(chan_t trig_source) {
    assert(trig_source < NUM_CHAN);
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_TRIG_CHAN, trig_source);
    state.trig_source = trig_source;
    pthread_mutex_unlock(&state_mutex);
}
chan_t scope_get_trig_source(void) {
    return state.trig_source;
}

void scope_set_trig_width(int trig_width) {
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_TRIG_PULSE_WIDTH, trig_width);
    state.trig_width = trig_width;
    pthread_mutex_unlock(&state_mutex);
}
int scope_get_trig_width(void) {
    return state.trig_width;
}

void scope_set_math_en(int math_en) {
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_MATH_EN, math_en);
    state.math_en = math_en;
    pthread_mutex_unlock(&state_mutex);
}
int scope_get_math_en(void) {
    return state.math_en;
}

void scope_set_math_mode(math_mode_t mode) {
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_MATH_MODE, mode);
    state.math_mode = mode;
    pthread_mutex_unlock(&state_mutex);
}
math_mode_t scope_get_math_mode(void) {
    return state.math_mode;
}

void scope_set_math_offset(int offset) {

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_OFFSET + 2*4, offset);
    state.math_offset = offset;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_math_offset(void) {
    return state.math_offset;
}

void scope_set_math_scale(int scale) {
    assert(scale > 0);

    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_VSCALE + 2*4, scale);
    state.math_scale = scale;
    pthread_mutex_unlock(&state_mutex);
}
double scope_get_math_scale(void) {
    double volts_per_pix = 0.001 * 8; // account for mult by 8 in display module
    // vscale value multiplies with the pixel address
    volts_per_pix /= state.math_scale;
    volts_per_pix *= 4; // Allow for the scale down factor
    volts_per_pix *= 2; // Math gets scaled before add/sub

    return volts_per_pix * POINTS_PER_GRID;
}

void scope_set_math_ch0(chan_t chan) {
    assert(chan < NUM_CHAN);
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_MATH_CH0, chan);
    state.math_ch0 = chan;
    pthread_mutex_unlock(&state_mutex);
}
chan_t scope_get_math_ch0(void) {
    return state.math_ch0;
}

void scope_set_math_ch1(chan_t chan) {
    assert(chan < NUM_CHAN);
    pthread_mutex_lock(&state_mutex);
    setcfg(CFG_MATH_CH1, chan);
    state.math_ch1 = chan;
    pthread_mutex_unlock(&state_mutex);
}
chan_t scope_get_math_ch1(void) {
    return state.math_ch1;
}
