#include "display.h"
#include "scope.h"
#include "panel.h"

#include <stdio.h>
#include <stdarg.h>
#include <sys/time.h>
#include <stdlib.h>

static const color_t red    = {1.0, 0.0, 0.0, 1.0};
static const color_t green  = {0.0, 1.0, 0.0, 1.0};
static const color_t blue   = {0.0, 0.0, 1.0, 1.0};
static const color_t yellow = {1.0, 1.0, 0.0, 1.0};
static const color_t black  = {0.0, 0.0, 0.0, 1.0};
static const color_t white  = {1.0, 1.0, 1.0, 1.0};
static const color_t light_blue = {0.05, 0.72, 0.98, 1.0};
static const color_t panel_bg = {0.87, 0.44, 0.44, 1.0};
static const color_t transparent = {0, 0, 0, 0};

static void crprintf(cairo_t *cr, uint32_t x, uint32_t y, const char *fmt, ...) {
    char msg[256];
    va_list args;
    va_start (args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);

    cairo_save(cr);
    cairo_set_source_rgba(cr, 0, 0, 0, 1);
    cairo_translate(cr, x, y+13);

    cairo_show_text(cr, msg);

    cairo_restore(cr);

    va_end(args);
}

static cairo_surface_t *banner_surf;
static cairo_pattern_t *banner_pattern;

static void init_name_text (void) {
    // Load the "SillyScope" mask image from a png file
    banner_surf = cairo_image_surface_create_from_png("silly-banner.png");
    if (cairo_surface_status(banner_surf) != CAIRO_STATUS_SUCCESS) {
        printf("ERROR: Failed to load silly banner\n");
        exit(1);
    }

    // Create a linear color gradient which will be masked by the "SillyScope" text
    banner_pattern = cairo_pattern_create_linear(0, 0, 414, 0);
    if (cairo_pattern_status(banner_pattern) != CAIRO_STATUS_SUCCESS) {
        printf("ERROR: Failed to create silly pattern\n");
        exit(1);
    }
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.0, 0.98, 0.313, 0.313);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.125, 0.647, 0.98, 0.313);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.25, 0.313, 0.98, 0.98);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.375, 0.647, 0.313, 0.98);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.5, 0.98, 0.313, 0.313);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.625, 0.647, 0.98, 0.313);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.75, 0.313, 0.98, 0.98);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 0.875, 0.647, 0.313, 0.98);
    cairo_pattern_add_color_stop_rgb(banner_pattern, 1.0, 0.98, 0.313, 0.313);
}

static void draw_name_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    // Translate the color gradient based on the current time
    struct timeval tp;
    gettimeofday(&tp, NULL);

    cairo_matrix_t mat;
    mat.xx = mat.yy = 1.0;
    mat.xy = mat.yx = 0.0;
    mat.y0 = 0.0;
    mat.x0 = (tp.tv_usec / 1000000.0) * 212;

    cairo_pattern_set_matrix(banner_pattern, &mat);

    // Erase all pixels previously drawn on this panel
    cairo_save(cr);
    cairo_set_operator(cr, CAIRO_OPERATOR_CLEAR);
    cairo_rectangle(cr, 0, 0, 212, 32);
    cairo_fill(cr);
    cairo_restore(cr);

    // Draw the text itself
    cairo_set_source(cr, banner_pattern);
    cairo_mask_surface(cr, banner_surf, 0, 0);
}

static void draw_trig_status_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    crprintf(cr, 10, 5, "Trigger status");
}

static void draw_trig_mode_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    const char *trig_on;
    if (scope_get_trig_en()) {
      trig_on = "ON";
    } else {
      trig_on = "OFF";
    }

    const char *trig_mode;

    switch(scope_get_trig_mode()) {
        case TRIG_RISING:
            trig_mode = "RISING";
            break;
        case TRIG_FALLING:
            trig_mode = "FALLING";
            break;
        case TRIG_PULSE_EQ:
            trig_mode = "PULSE_EQ";
            break;
        case TRIG_PULSE_LT:
            trig_mode = "PULSE_LT";
            break;
        case TRIG_PULSE_GT:
            trig_mode = "PULSE_GT";
            break;
        default:
            trig_mode = "ERR";
            break;
    }

    crprintf(cr, 5, 5, "%s CH%d %s", trig_on,
                scope_get_trig_source(),
                trig_mode);
}

static void draw_measureA_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    crprintf(cr, 10, 5, "Measure A");
}

static void draw_measureB_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    crprintf(cr, 10, 5, "Measure B");
}


static void draw_timescale_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    double timescale = scope_get_timescale();
    const char *prefix = "";
    if (timescale < 1.0) {
        if (timescale < 0.001) {
            prefix = "u";
            timescale *= 1000000;
        } else {
            prefix = "m";
            timescale *= 1000;
        }
    }

    crprintf(cr, 10, 5, "TS: %.3f %ss", timescale, prefix);
}

static void draw_chan_text (cairo_t *cr, void *args) {
    chan_t chan = (chan_t) args;

    if (scope_get_num_channels() >= chan) {
        double vscale = scope_get_vscale(chan);
        const char *prefix = "";
        if (vscale < 1.0) {
            if (vscale < 0.001) {
                prefix = "u";
                vscale *= 1000000;
            } else {
                prefix = "m";
                vscale *= 1000;
            }
        }
        crprintf(cr, 10, 5, "CH%d %.3f %sV", chan, vscale, prefix);
    }
}

static void draw_math_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    if (scope_get_math_en()) {
        const char *math_mode;

        switch(scope_get_math_mode()) {
            case MATH_ADD:
                math_mode = "+";
                break;
            case MATH_SUB:
                math_mode = "-";
                break;
            default:
                math_mode = "ERR";
                break;
        }

        double vscale = scope_get_math_scale();
        const char *prefix = "";
        if (vscale < 1.0) {
            if (vscale < 0.001) {
                prefix = "u";
                vscale *= 1000000;
            } else {
                prefix = "m";
                vscale *= 1000;
            }
        }
        crprintf(cr, 10, 5, "(CH%d %s CH%d) %.3f %sV", scope_get_math_ch0(), math_mode, scope_get_math_ch1(), vscale, prefix);
    }
}

static void draw_math_op_text (cairo_t *cr, void *args) {
    (void)args; // Don't have any args

    crprintf(cr, 10, 5, "math operator");
}


static panel_t top_panel = {
    .x = 0,
    .y = 0,
    .width = 640,
    .height = 480,
    .draw = 0
};

static panel_t low_panel = {
    .x = 0,
    .y = 448,
    .width = 640,
    .height = 32,
    .draw = 1,
    .bg_color = &red,
    .edge_color = &yellow,

    .callback = NULL
};

static panel_t low_p1 = {
    .x = 0,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_timescale_text
};

static panel_t low_p2 = {
    .x = 100,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_chan_text,
    .args = (void*) CHAN_1
};

static panel_t low_p3 = {
    .x = 200,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_chan_text,
    .args = (void*) CHAN_2
};

static panel_t low_p4 = {
    .x = 300,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_chan_text,
    .args = (void*) CHAN_3
};


static panel_t low_p5 = {
    .x = 400,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_chan_text,
    .args = (void*) CHAN_4
};

static panel_t low_p6 = {
    .x = 500,
    .y = 0,
    .width = 140,
    .height = 32,
    .draw = 1,
    .bg_color = &light_blue,
    .edge_color = &black,

    .callback = draw_math_text
};

static panel_t high_panel = {
    .x = 0,
    .y = 0,
    .width = 640,
    .height = 32,
    .draw = 0
};

static panel_t high_p1 = {
    .x = 0,
    .y = 0,
    .width = 212,
    .height = 32,
    .draw = 1,
    .bg_color = &transparent,
    .edge_color = &transparent,

    .callback = draw_name_text
};

static panel_t high_p2 = {
    .x = 212,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 0,
    .bg_color = &green,
    .edge_color = &black,

    .callback = draw_trig_status_text
};
static panel_t high_p3 = {
    .x = 540,
    .y = 0,
    .width = 100,
    .height = 32,
    .draw = 1,
    .bg_color = &green,
    .edge_color = &black,

    .callback = draw_trig_mode_text
};
static panel_t high_p4 = {
    .x = 412,
    .y = 0,
    .width = 114,
    .height = 32,
    .draw = 0,
    .bg_color = &green,
    .edge_color = &black,

    .callback = draw_measureA_text
};

static panel_t high_p5 = {
    .x = 526,
    .y = 0,
    .width = 114,
    .height = 32,
    .draw = 0,
    .bg_color = &green,
    .edge_color = &black,

    .callback = draw_measureB_text
};

// Register the panel hierarchy with the panel library
void display_init (void) {
    init_name_text();

    panel_register(&top_panel, NULL);
    panel_register(&low_panel, &top_panel);
    panel_register(&low_p1, &low_panel);
    panel_register(&low_p2, &low_panel);
    panel_register(&low_p3, &low_panel);
    panel_register(&low_p4, &low_panel);
    panel_register(&low_p5, &low_panel);
    panel_register(&low_p6, &low_panel);

    panel_register(&high_panel, &top_panel);
    panel_register(&high_p1, &high_panel);
    panel_register(&high_p2, &high_panel);
    panel_register(&high_p3, &high_panel);
    panel_register(&high_p4, &high_panel);
    panel_register(&high_p5, &high_panel);
}

static volatile int redraw_pending = 0;

void display_redraw (cairo_t *cr) {
    panel_draw(cr, &top_panel);
    redraw_pending = 0;
}

void display_redraw_banner (cairo_t *cr) {
    panel_draw(cr, &high_panel);
}

void display_request_redraw(void) {
    redraw_pending = 1;
}

int display_redraw_pending(void) {
    return redraw_pending;
}
