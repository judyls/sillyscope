#ifndef _PANEL_H
#define _PANEL_H

#include <stdint.h>
#include <cairo.h>

#ifndef NULL
#define NULL ((void*)0)
#endif

typedef struct {
    double r;
    double g;
    double b;
    double a;
} color_t;

typedef void (*draw_callback_t)(cairo_t *cr, void *args);

struct TAG_panel;

typedef struct {
    struct TAG_panel *peer_next;
    struct TAG_panel *children_head;
    struct TAG_panel *parent;
} panel_priv_t;

typedef struct TAG_panel {
    uint32_t x;
    uint32_t y;
    uint32_t width;
    uint32_t height;
    int draw;
    const color_t *bg_color;
    const color_t *edge_color;

    draw_callback_t callback;
    void *args;

    panel_priv_t priv;
} panel_t;

void panel_register(panel_t *panel, panel_t *parent);
void panel_draw(cairo_t *cr, panel_t *panel);

#endif //_PANEL_H
